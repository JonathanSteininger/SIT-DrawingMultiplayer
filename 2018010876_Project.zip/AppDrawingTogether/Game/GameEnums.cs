﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDrawingTogether.Game
{
    internal enum LineThickness
    {
        Small,
        Medium,
        Large,
        ExtraLarge,
        Custom
    }
}
