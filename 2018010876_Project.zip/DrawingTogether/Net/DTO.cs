﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrawingTogether.Net
{
    internal interface DTO
    {
        string Type { get; }
    }
}
